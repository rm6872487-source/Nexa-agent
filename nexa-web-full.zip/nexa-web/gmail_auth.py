#!/usr/bin/env python3
"""
Modul autentikasi Google (Gmail + Calendar + Drive) untuk Nexa Agent.

Kenapa dipisah dari agent.py? Supaya:
1. agent.py tetap bisa dipakai tanpa Google API (kalau user gak mau setup OAuth).
2. Logic auth/token storage gampang diaudit terpisah dari logic tool lainnya.

Satu credentials.json & satu token (token_google.json) dipakai bersama untuk
Gmail, Calendar, DAN Drive sekaligus — supaya setup cuma sekali, bukan OAuth
terpisah per fitur. Begitu user approve, agent dapat scope gabungan (readonly+
send gmail, events calendar, readonly drive) dalam satu login.

PENTING UNTUK SIAPAPUN YANG CLONE REPO INI:
Project ini TIDAK menyertakan credentials.json atau token siapapun. Setiap orang
yang mau pakai fitur Gmail/Calendar/Drive WAJIB bikin OAuth Client ID sendiri
(gratis) di Google Cloud Console miliknya sendiri. Ini bukan langkah opsional/
ribet-ribet amat — ini prinsip dasar OAuth yang aman: jangan ada satu Client ID
yang dipakai bareng-bareng oleh semua user sebuah project open source, apalagi
di-hardcode ke dalam kode.

Cara setup (sekali aja per orang):
1. Buka https://console.cloud.google.com/ -> bikin project baru (bebas nama).
2. Enable "Gmail API", "Google Calendar API", DAN "Google Drive API" di API
   Library (tiga-tiganya).
3. Buka "OAuth consent screen" -> pilih "External" -> isi nama app & email kamu
   -> di bagian "Test users" tambahkan email Gmail kamu sendiri.
4. Buka "Credentials" -> "Create Credentials" -> "OAuth client ID" -> pilih
   "Desktop app" -> kasih nama bebas -> Create.
5. Download JSON-nya, rename jadi `credentials.json`, taruh di folder project
   ini (sejajar dengan agent.py). File ini SUDAH otomatis di-gitignore.
6. Jalankan agent, pertama kali pakai tool gmail_read/gmail_send/
   calendar_create_event/drive_list_files/drive_read_file akan otomatis buka
   browser minta login & izin akses Gmail + Calendar + Drive kamu sekaligus.
   Setelah login sekali, token disimpan di `token_google.json` (lokal, juga
   di-gitignore) supaya gak perlu login ulang tiap jalanin agent.

Scope yang dipakai sengaja dibatasi:
- gmail.readonly       -> buat baca/cari email
- gmail.send           -> buat kirim email
- calendar.events      -> buat baca & bikin event kalender (tidak bisa hapus
                          kalender itu sendiri atau ubah setting kalender lain)
- drive.readonly       -> buat list/cari/baca isi file Drive (TIDAK bisa
                          upload, edit, hapus, atau ubah permission file apapun)
Bukan full akses (gmail.modify / https://mail.google.com/ / calendar penuh /
drive penuh), supaya agent gak bisa menghapus email, ubah-ubah inbox, merusak
kalender, atau mengubah/menghapus file Drive kamu di luar scope yang disebutkan.

CATATAN MIGRASI: kalau sebelumnya kamu sudah pernah login dan punya
token_google.json dari versi project ini yang lebih lama (sebelum ada Drive),
token itu cuma punya scope Gmail+Calendar dan TIDAK otomatis dapat akses Drive.
Hapus token_google.json (atau biarkan saja, akan otomatis ke-refresh/minta
login ulang) supaya agent membuat token baru dengan scope gabungan terbaru
saat kamu pertama kali memanggil tool Drive di versi ini.
"""

import os
from pathlib import Path

SCOPES = [
    "https://www.googleapis.com/auth/gmail.readonly",
    "https://www.googleapis.com/auth/gmail.send",
    "https://www.googleapis.com/auth/calendar.events",
    "https://www.googleapis.com/auth/drive.readonly",
]

BASE_DIR = Path(__file__).parent
CREDENTIALS_FILE = BASE_DIR / "credentials.json"
TOKEN_FILE = BASE_DIR / "token_google.json"

_service_cache = None
_calendar_service_cache = None
_drive_service_cache = None


class GmailNotConfigured(Exception):
    """Dilempar kalau credentials.json belum ada / belum di-setup."""
    pass


def _get_credentials():
    """
    Return objek Credentials Google yang siap dipakai (sudah ter-autentikasi),
    dipakai bersama oleh Gmail dan Calendar (satu token, scope gabungan).

    Login pertama kali akan otomatis buka browser (atau kasih URL kalau di
    environment tanpa GUI/browser, misal Termux) -> user login & approve ->
    token disimpan ke TOKEN_FILE untuk dipakai lagi nanti tanpa login ulang.
    """
    if not CREDENTIALS_FILE.exists():
        raise GmailNotConfigured(
            f"credentials.json tidak ditemukan di {BASE_DIR}.\n"
            "Setup OAuth Client ID dulu di Google Cloud Console (gratis), lihat "
            "instruksi lengkap di README.md bagian 'Setup Gmail', lalu taruh file "
            "credentials.json di folder yang sama dengan agent.py."
        )

    try:
        from google.auth.transport.requests import Request
        from google.oauth2.credentials import Credentials
        from google_auth_oauthlib.flow import InstalledAppFlow
    except ImportError:
        raise GmailNotConfigured(
            "Library Google API belum terinstall. Jalankan:\n"
            "  pip install google-auth-oauthlib google-api-python-client"
        )

    creds = None
    if TOKEN_FILE.exists():
        creds = Credentials.from_authorized_user_file(str(TOKEN_FILE), SCOPES)

    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(str(CREDENTIALS_FILE), SCOPES)
            # run_local_server buka browser otomatis kalau ada display; kalau tidak
            # (misal SSH/Termux headless), library ini fallback otomatis ke mode
            # yang menampilkan URL untuk dibuka manual.
            creds = flow.run_local_server(port=0)
        TOKEN_FILE.write_text(creds.to_json(), encoding="utf-8")
        # Kunci permission file token biar cuma owner yang bisa baca (best-effort,
        # no-op di Windows).
        try:
            os.chmod(TOKEN_FILE, 0o600)
        except Exception:
            pass

    return creds


def get_gmail_service():
    """
    Return objek Gmail API service yang siap dipakai (sudah ter-autentikasi).
    Di-cache di memori supaya gak re-auth tiap panggilan tool dalam 1 sesi proses.
    """
    global _service_cache
    if _service_cache is not None:
        return _service_cache

    from googleapiclient.discovery import build

    creds = _get_credentials()
    _service_cache = build("gmail", "v1", credentials=creds)
    return _service_cache


def get_calendar_service():
    """
    Return objek Google Calendar API service yang siap dipakai (sudah
    ter-autentikasi). Pakai token & credentials yang sama dengan Gmail
    (scope calendar.events sudah termasuk dalam SCOPES gabungan di atas).
    Di-cache di memori supaya gak re-auth tiap panggilan tool dalam 1 sesi proses.
    """
    global _calendar_service_cache
    if _calendar_service_cache is not None:
        return _calendar_service_cache

    from googleapiclient.discovery import build

    creds = _get_credentials()
    _calendar_service_cache = build("calendar", "v3", credentials=creds)
    return _calendar_service_cache


def get_drive_service():
    """
    Return objek Google Drive API service yang siap dipakai (sudah
    ter-autentikasi). Pakai token & credentials yang sama dengan Gmail/Calendar
    (scope drive.readonly sudah termasuk dalam SCOPES gabungan di atas).
    Di-cache di memori supaya gak re-auth tiap panggilan tool dalam 1 sesi proses.
    """
    global _drive_service_cache
    if _drive_service_cache is not None:
        return _drive_service_cache

    from googleapiclient.discovery import build

    creds = _get_credentials()
    _drive_service_cache = build("drive", "v3", credentials=creds)
    return _drive_service_cache


def revoke_gmail_auth():
    """Hapus token lokal (logout dari Gmail & Calendar & Drive sekaligus, satu
    token). User perlu login ulang setelah ini."""
    global _service_cache, _calendar_service_cache, _drive_service_cache
    _service_cache = None
    _calendar_service_cache = None
    _drive_service_cache = None
    if TOKEN_FILE.exists():
        TOKEN_FILE.unlink()
        return True
    return False
