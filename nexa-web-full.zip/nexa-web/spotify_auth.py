#!/usr/bin/env python3
"""
Modul autentikasi Spotify untuk Nexa Agent — KHUSUS SEARCH, bukan playback.

Kenapa beda dari gmail_auth.py (yang OAuth login user)?
Karena fitur yang dipakai cuma search lagu/artist/album/playlist, yang di
Spotify Web API masuk kategori "Client Credentials Flow" — auth level
APLIKASI, bukan auth level USER. Artinya:
- TIDAK ada browser login/consent screen sama sekali.
- TIDAK bisa dipakai untuk kontrol playback (play/pause/skip), baca playlist
  pribadi/private, atau apapun yang butuh izin akun Spotify user. Kalau nanti
  mau itu, butuh flow OAuth user terpisah (Authorization Code Flow) DAN
  Spotify Premium (Spotify Web API menolak kontrol playback untuk akun Free).
- Cukup pakai Client ID + Client Secret aplikasi (gratis, dari Spotify for
  Developers), token didapat otomatis di belakang layar tanpa interaksi user.

PENTING UNTUK SIAPAPUN YANG CLONE REPO INI:
Project ini TIDAK menyertakan Client ID/Secret siapapun. Setiap orang yang mau
pakai fitur Spotify search WAJIB bikin app sendiri (gratis) di Spotify for
Developers Dashboard miliknya sendiri.

Cara setup (sekali aja per orang):
1. Buka https://developer.spotify.com/dashboard -> login pakai akun Spotify
   kamu (Free maupun Premium, dua-duanya bisa).
2. Klik "Create app" -> isi nama app (bebas), description (bebas).
3. Redirect URI WAJIB diisi walau tidak benar-benar dipakai untuk search-only
   flow ini (syarat form Spotify) -> isi saja "http://localhost:8080/callback".
4. Centang "Web API" di bagian "Which API/SDKs are you planning to use?".
5. Setelah app dibuat, buka "Settings" -> catat "Client ID" dan klik
   "View client secret" untuk lihat "Client Secret".
6. Set sebagai environment variable sebelum jalanin agent:
     export SPOTIFY_CLIENT_ID="xxxxxxxx"
     export SPOTIFY_CLIENT_SECRET="xxxxxxxx"
   (atau taruh di file .env kalau project kamu pakai python-dotenv)

Client ID/Secret ini BUKAN password akun Spotify kamu — cuma identitas
aplikasi, dan scope-nya otomatis terbatas ke search publik saja (Client
Credentials Flow secara desain tidak bisa mengakses data user apapun).
"""

import os
import time

import requests

SPOTIFY_CLIENT_ID = os.environ.get("SPOTIFY_CLIENT_ID", "")
SPOTIFY_CLIENT_SECRET = os.environ.get("SPOTIFY_CLIENT_SECRET", "")
TOKEN_URL = "https://accounts.spotify.com/api/token"

_token_cache = None
_token_expires_at = 0


class SpotifyNotConfigured(Exception):
    """Dilempar kalau SPOTIFY_CLIENT_ID / SPOTIFY_CLIENT_SECRET belum di-set."""
    pass


def get_access_token() -> str:
    """
    Return access token Spotify yang valid (Client Credentials Flow).
    Di-cache di memori sampai mendekati waktu expired (token Spotify berlaku
    1 jam), supaya tidak request token baru di setiap pencarian.
    """
    global _token_cache, _token_expires_at

    if _token_cache and time.time() < _token_expires_at:
        return _token_cache

    if not SPOTIFY_CLIENT_ID or not SPOTIFY_CLIENT_SECRET:
        raise SpotifyNotConfigured(
            "SPOTIFY_CLIENT_ID dan/atau SPOTIFY_CLIENT_SECRET belum di-set.\n"
            "Buat app gratis di https://developer.spotify.com/dashboard, lalu:\n"
            '  export SPOTIFY_CLIENT_ID="..."\n'
            '  export SPOTIFY_CLIENT_SECRET="..."\n'
            "Lihat README.md bagian 'Setup Spotify' untuk langkah lengkap."
        )

    resp = requests.post(
        TOKEN_URL,
        data={"grant_type": "client_credentials"},
        auth=(SPOTIFY_CLIENT_ID, SPOTIFY_CLIENT_SECRET),
        timeout=15,
    )
    if resp.status_code != 200:
        raise RuntimeError(
            f"Gagal mendapatkan token Spotify (status {resp.status_code}): {resp.text[:300]}"
        )

    data = resp.json()
    _token_cache = data["access_token"]
    # Kasih buffer 60 detik sebelum expired sebenarnya, biar gak kepepet di tengah request.
    _token_expires_at = time.time() + data.get("expires_in", 3600) - 60
    return _token_cache
